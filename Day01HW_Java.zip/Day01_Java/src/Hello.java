public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello, my name is Shin");
        System.out.println("Today's date is: 2026-05-06");
    }
}
