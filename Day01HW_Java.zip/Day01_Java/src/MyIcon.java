import java.util.Scanner;

public class MyIcon {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a symbol: ");
        char symbol = sc.next().charAt(0);

        System.out.print("Enter a number: ");
        int number = sc.nextInt();

        for (int i = 0; i < number; i++) {
            System.out.print(symbol);
        }
    }
}
